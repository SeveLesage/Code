# CONSIGNES

## Nomenclature et organisation
- vous devez créer un nouveau dossier à la racine du dossier code qui s'appelera votreprenomPIX
- Dedans vous devez avoir un fichier index.html // un dossier CSS avec style.css à l'intérieur // Un dossier img avec toutes les ressources que je vous envoie // et ce fichier à la racine

## Typos et couleurs
- Pour les titres vous devez utiliser la typo Aclonica (c'est normal que ce ne soit pas exactement le même rendu que sur la maquette)
- les couleurs : pour tous les endroits orange : #FF4F13
                pour le premier bloc avec les images : #E6E6E6
                pour le footer : #343434

## Pense-bête
- Mettez des commentaires
- Faites d'abord tout le HTML
- Reset Eric Meyer